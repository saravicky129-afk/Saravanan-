package com.saravana.caller

/**
 * Name -> Meaning database.
 * Add as many names as you want here in this exact format.
 * "drawableName" must match an image file placed in res/drawable (without extension).
 * If you don't have an image for a name, use "default_icon".
 */

data class NameInfo(
    val displayName: String,
    val meaning: String,
    val drawableName: String = "default_icon"
)

object NameData {

    val database: Map<String, NameInfo> = mapOf(
        "saravan" to NameInfo(
            displayName = "சரவணன் (Saravanan)",
            meaning = "Saravana Poigai (sacred lotus pond) la piranthavar. Lord Murugan-oda peyar. War, wisdom, youth-oda kadavul. Vel yeந்தியவர்.",
            drawableName = "default_icon"
        ),
        "saravanan" to NameInfo(
            displayName = "சரவணன் (Saravanan)",
            meaning = "Saravana Poigai (sacred lotus pond) la piranthavar. Lord Murugan-oda peyar. War, wisdom, youth-oda kadavul.",
            drawableName = "default_icon"
        ),
        "kumar" to NameInfo(
            displayName = "குமார் (Kumar)",
            meaning = "இளையவன், இளவரசன் (Prince, young one). Murugan-oda vera peyar - 'Kumaran'.",
            drawableName = "default_icon"
        ),
        "vel" to NameInfo(
            displayName = "வேல் (Vel)",
            meaning = "Murugan yendhiya divine spear - arivukum, dharmathukum symbol.",
            drawableName = "default_icon"
        )
        // 👇 Add more names below in the same format:
        // "yourname" to NameInfo(
        //     displayName = "Display Name",
        //     meaning = "Meaning here",
        //     drawableName = "default_icon"
        // ),
    )

    fun lookup(rawName: String): NameInfo {
        val key = rawName.trim().lowercase()
        // exact match first
        database[key]?.let { return it }
        // partial match (first name inside a full contact name)
        for ((k, v) in database) {
            if (key.contains(k)) return v
        }
        return NameInfo(
            displayName = rawName,
            meaning = "Idha peyaruku meaning innum add pannala. NameData.kt file-la add pannikonga.",
            drawableName = "default_icon"
        )
    }
}
