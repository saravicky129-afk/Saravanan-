package com.saravana.caller

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageView
import android.widget.TextView
import android.widget.Button

class CallerDisplayActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen + turn screen on
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        setContentView(R.layout.activity_caller_display)

        val rawName = intent.getStringExtra("caller_name") ?: "Unknown"
        val info = NameData.lookup(rawName)

        findViewById<TextView>(R.id.tvName).text = info.displayName
        findViewById<TextView>(R.id.tvMeaning).text = info.meaning

        val imageView = findViewById<ImageView>(R.id.ivImage)
        val resId = resources.getIdentifier(info.drawableName, "drawable", packageName)
        if (resId != 0) {
            imageView.setImageResource(resId)
        }

        findViewById<Button>(R.id.btnClose).setOnClickListener {
            finish()
        }
    }
}
