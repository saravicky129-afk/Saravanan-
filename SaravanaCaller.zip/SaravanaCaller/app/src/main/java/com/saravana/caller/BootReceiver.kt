package com.saravana.caller

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Placeholder: ensures app's receivers stay registered after device reboot.
// No action needed here since CallReceiver is a manifest-registered receiver.
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // No-op. Kept for future use (e.g. showing a "ready" notification after boot).
    }
}
