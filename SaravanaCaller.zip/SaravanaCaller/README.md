# Saravana Caller - Android App

Call varum bothu, saved contact name-ku matching meaning + image FULL SCREEN BLACK background-la kaatum app.

## ⚠️ Important - Read First
- Idhu **native Android app**. PWA/website-la call detect panna mudiyathu — so idha Android Studio-la build pannanum.
- Google Play-la idhu maadhiri apps (call permissions + full screen overlay) approval kidaikardhu kashtam. Personal use-ku (sideload) mattum recommend pannuren.
- Android 10+ la background-la irundhu neraya activity start panna restriction irukku, so naan "Full Screen Notification" method use pannirukken (WhatsApp call screen madhiri) — idhu reliable-a work aagum.

## How to Build (Android Studio)

1. Android Studio open pannunga (latest version download: https://developer.android.com/studio)
2. **Open** → intha `SaravanaCaller` folder select pannunga
3. Gradle sync aagum varaikkum wait pannunga (first time konjam time edukkum)
4. Phone-a USB-la connect pannunga, USB debugging ON pannunga (Settings → Developer Options)
5. Top-la green ▶ Run button click pannunga → phone select pannunga → Run

## APK File Direct-a Venumna
1. Android Studio-la: **Build → Build Bundle(s)/APK(s) → Build APK(s)**
2. APK file kidaikum: `app/build/outputs/apk/debug/app-debug.apk`
3. Andha file phone-ku transfer pannunga (WhatsApp/USB/Drive), install pannunga
4. "Unknown sources" install allow pannanum (Settings-la varum popup)

## App Open Pannina Aprom
1. App open pannunga
2. **"1. Grant Call Permissions"** click pannunga → எல்லா permissions Allow pannunga
3. **"2. Allow Display Over Other Apps"** click pannunga → next screen-la app-a toggle ON pannunga
4. Done! Ippo call varum bothu automatic-a full screen-la name + meaning varum

## Names & Meanings Add/Edit Panna

File: `app/src/main/java/com/saravana/caller/NameData.kt`

Ippo already irukku: saravan, saravanan, kumar, vel

Puthusa add panna, indha format follow pannunga:
```kotlin
"puthu peyar" to NameInfo(
    displayName = "Display Name",
    meaning = "Meaning here",
    drawableName = "default_icon"
),
```

Contact-oda saved name partial match aagum (e.g. "Saravanan Kumar" nu save pannirundha, "saravanan" match aagi andha meaning varum).

## Image Maathanum Na
1. Ungaluku venum image-a `.png` format-la `app/src/main/res/drawable/` folder-ku podunga (e.g. `murugan1.png`)
2. `NameData.kt` file-la andha name-oda `drawableName = "murugan1"` nu maathunga

## Permissions Idhukku Ethukku
| Permission | Why |
|---|---|
| READ_PHONE_STATE | Call ringing-a detect panna |
| READ_CALL_LOG / READ_CONTACTS | Incoming number-oda saved name eduka |
| SYSTEM_ALERT_WINDOW / Overlay | Lock screen mela display panna |
| POST_NOTIFICATIONS | Full screen intent trigger panna (Android 13+) |

## Note on Privacy
Idhu ungal own phone-la personal use-ku dhaan. Call log/contacts data device-a vittu எங்கும் pogathu — fully offline, local-a mattum work aagum.
